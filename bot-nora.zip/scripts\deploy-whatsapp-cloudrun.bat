@echo off
echo ====================================================================
echo  DEPLOY DO WHATSAPP BAILEYS (NORA AI) PARA O GOOGLE CLOUD RUN (24/7)
echo ====================================================================
echo.

SET PROJECT_ID=studio-2629657699-721b1
SET SERVICE_NAME=nora-whatsapp-service
SET REGION=us-central1

echo [1/3] Habilitando servicos do Google Cloud no projeto %PROJECT_ID%...
call gcloud services enable run.googleapis.com containerregistry.googleapis.com artifactregistry.googleapis.com --project %PROJECT_ID%

echo.
echo [2/3] Renomeando arquivos temporariamente para o build...
ren Dockerfile Dockerfile.nextjs
ren Dockerfile.whatsapp Dockerfile

call gcloud run deploy %SERVICE_NAME% ^
  --source . ^
  --project %PROJECT_ID% ^
  --region %REGION% ^
  --allow-unauthenticated ^
  --no-cpu-throttling ^
  --memory 512Mi ^
  --set-env-vars NORA_API_URL="https://nora.tec.br" ^
  --port 8080

echo Restaurando nomes dos arquivos originais...
ren Dockerfile Dockerfile.whatsapp
ren Dockerfile.nextjs Dockerfile

echo.
echo ====================================================================
echo ✅ DEPLOY CONCLUIDO COM SUCESSO!
echo ====================================================================
pause
